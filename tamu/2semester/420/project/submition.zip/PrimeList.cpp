#include "PrimeList.h"

unsigned int g_number_of_primes = 20;
